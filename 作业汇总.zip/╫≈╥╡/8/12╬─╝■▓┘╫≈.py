# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 14:24:06 2018

第八题：保存淘宝数据(小组项目)
1.每个组员爬取100页数据(同一种商品)，条件是北京，上海，广州，成都...
2.保存的商品信息有(同第六题),并且是以为csv格式保存
3.单个组员求出当前城市的商品的众数(最多的价格)
4.小组文件合并，求出商品的平均价格

@author: Administrator
"""


#第七题：保存淘宝数据(小组项目)
#1.每个组员爬取100页数据(同一种商品)，条件是北京，上海，广州，成都...
#2.保存的商品信息有(同第六题),并且是以为csv格式保存
#3.单个组员求出当前城市的商品的众数(最多的价格)
#4.小组文件合并，求出商品的平均价格
import urllib.request as r#导入联网工具包，命令为r
ur2='https://s.taobao.com/search?q=%E7%BE%BD%E7%BB%92%E6%9C%8D&bcoffset=6&ntoffset=6&p4ppushleft=1%2C48&loc=%E5%B9%BF%E5%B7%9E&s=0&ajax=true'
data2=r.urlopen(ur2).read().decode('utf-8')
import json
data2=json.loads(data2)
for i in range(0,36):
    a=data2['mods']['itemlist']['data']['auctions'][i]['raw_title']#商品名
    b=data2['mods']['itemlist']['data']['auctions'][i]['view_price']#价格
    c=data2['mods']['itemlist']['data']['auctions'][i]['view_sales']#付款
    d=data2['mods']['itemlist']['data']['auctions'][i]['nick']#店铺名
    e=data2['mods']['itemlist']['data']['auctions'][i]['item_loc']#地址
    print('{},{},{},{},{}'.format(a,b,c,d,e))
    f=open('./tao.csv','a')#csv表格文件，以逗号分割
    f.write('{},{},{},{},{}\n'.format(a,b,c,d,e))
    f.close()#关闭文件，保存文件   
import urllib.request as r#导入联网工具包，命令为r
ur1='https://s.taobao.com/search?q=%E7%BE%BD%E7%BB%92%E6%9C%8D&bcoffset=3&ntoffset=3&p4ppushleft=1%2C48&loc=%E5%B9%BF%E5%B7%9E&s=44&ajax=true'
data1=r.urlopen(ur1).read().decode('utf-8')
import json
data1=json.loads(data1)
for i in range(0,44):
    a=data1['mods']['itemlist']['data']['auctions'][i]['raw_title']#商品名
    b=data1['mods']['itemlist']['data']['auctions'][i]['view_price']#价格
    c=data1['mods']['itemlist']['data']['auctions'][i]['view_sales']#付款
    d=data1['mods']['itemlist']['data']['auctions'][i]['nick']#店铺名
    e=data1['mods']['itemlist']['data']['auctions'][i]['item_loc']#地址
    print('{},{},{},{},{}'.format(a,b,c,d,e))
    f=open('./tao.csv','a')#csv表格文件，以逗号分割
    f.write('{},{},{},{},{}\n'.format(a,b,c,d,e))
    f.close()#关闭文件，保存文件    
import urllib.request as r#导入联网工具包，命令为r
ur2='https://s.taobao.com/search?q=%E7%BE%BD%E7%BB%92%E6%9C%8D&bcoffset=3&ntoffset=0&p4ppushleft=1%2C48&loc=%E5%B9%BF%E5%B7%9E&s=88&ajax=true'
data2=r.urlopen(ur2).read().decode('utf-8')
import json
data2=json.loads(data2)
for i in range(0,44):
    a=data2['mods']['itemlist']['data']['auctions'][i]['raw_title']#商品名
    b=data2['mods']['itemlist']['data']['auctions'][i]['view_price']#价格
    c=data2['mods']['itemlist']['data']['auctions'][i]['view_sales']#付款
    d=data2['mods']['itemlist']['data']['auctions'][i]['nick']#店铺名
    e=data2['mods']['itemlist']['data']['auctions'][i]['item_loc']#地址
    print('商品名:{},价格:{},付款:{},店铺名:{},地址:{}'.format(a,b,c,d,e))
    f=open('./tao.csv','a')#csv表格文件，以逗号分割
    f.write('{},{},{},{},{}\n'.format(a,b,c,d,e))
    f.close()#关闭文件，保存文件
#使用循环语句 
for j in range(100):
    if j>=3:
        k=j*44
        import urllib.request as r#导入联网工具包，命令为r
        ur3='https://s.taobao.com/search?q=%E7%BE%BD%E7%BB%92%E6%9C%8D&bcoffset=-3&ntoffset=-3&p4ppushleft=1%2C48&loc=%E5%B9%BF%E5%B7%9E&s={}&ajax=true'.format(k)
        data3=r.urlopen(ur3).read().decode('utf-8')
        import json
        data3=json.loads(data3)
        for i in range(len(data3['mods']['itemlist']['data']['auctions'])):
            a=data3['mods']['itemlist']['data']['auctions'][i]['raw_title']#商品名
            b=data3['mods']['itemlist']['data']['auctions'][i]['view_price']#价格
            c=data3['mods']['itemlist']['data']['auctions'][i]['view_sales']#付款
            d=data3['mods']['itemlist']['data']['auctions'][i]['nick']#店铺名
            e=data3['mods']['itemlist']['data']['auctions'][i]['item_loc']#地址
            f=open('./tao.csv','a')#csv表格文件，以逗号分割
            f.write('{},{},{},{},{}\n'.format(a,b,c,d,e))
    print('第{}页已经爬取!'.format(j+1))
            #f.close()#关闭文件，保存文件















