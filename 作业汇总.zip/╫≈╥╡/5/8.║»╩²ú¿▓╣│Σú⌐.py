﻿# -*- coding: utf-8 -*-
"""
Created on Thu Jun 21 14:39:54 2018
函数：
变量(生命周期)
全局变量，局部变量(函数内)
练习五:实现练习四，
1.使用函数写出来。定义函数，输出每一天6:00,12:00,18:00的天气信息
2.打印折线图,使用字符串的*号操作
10----------
5-----
@author: Administrator
"""
######################################### 作业5
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=laibin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data=json.loads(data)
  
def msg(b):
    a3=data['city']['name']
    b3=data['list'][b]['dt_txt']
    c3=data['list'][b]['main']['temp']
    d3=data['list'][b]['weather'][0]['description']#中文
    e3=data['list'][b]['main']['pressure']
    f3=data['list'][b]['main']['temp_max']
    g3=data['list'][b]['main']['temp_min']
    #print('城市:来宾,在{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b3,c3,d3,e3,f3,g3))
    print('{},temp:{}'.format(b3,c3),int(c3)*'*')
msg(1)
msg(3)
# print("温馨提醒:今天雨转多云，提示带伞,今天温度怡人，穿短袖")
msg(7)
msg(9)
msg(11)
# print("温馨提醒:今天雨转多云，提示带伞,今天温度怡人")
msg(15)
msg(17)
msg(19)
msg(22)
msg(25)
msg(27)
msg(30)
msg(33)
msg(35)
def dy(c3):
    c3=data['list'][b]['main']['temp']
    print('{}'.formatc3)




























print(a)




