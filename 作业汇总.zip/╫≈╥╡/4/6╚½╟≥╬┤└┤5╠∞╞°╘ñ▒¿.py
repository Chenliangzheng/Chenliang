# -*- coding: utf-8 -*-
"""
Created on Thu Jun 21 10:48:22 2018
全球未来5天气预报
2018-06-21 03:00:00    按照3小时一次预报
2018-06-21 06:00:00
2018-06-21 09:00:00------当前时间
2018-06-21 12:00:00
2018-06-25 21:00:00

第四题：求出未来5天天气
1.打印每天的6:00,12:00,18:00的天气(城市,温度，情况，气压，最高温度，最低温度)
2.同上写出[英文版的]
3.根据天气的情况，给出建议：例如，今天下雨，提示带伞。今天温度高，穿衬衫...三个件以上
4.根据温度打印出温度折线图
    28——————————————————————————————
    30——————————————————————————————————
    10——————————————————
5.打印出其他10个城市的天气，计算出天气排名，按着大到小的顺序。

@author: Administrator
"""
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=laibin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data=json.loads(data)
#data字典-》list列表-》index 0 字典-》main字典-》temp变量
data['list'][0]['main']['temp']
#data字典-》list列表-》index 0 字典-》main字典-》temp_max变量
data['list'][0]['main']['temp_max']
#data字典-》list列表-》index 0 字典-》main字典-》temp_min变量
data['list'][0]['main']['temp_min']
############################################################作业4
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=laibin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data=json.loads(data)
t=0
a1=data['city']['name']
b1=data['list'][t]['dt_txt']
c1=data['list'][t]['main']['temp']
d1=data['list'][t]['weather'][0]['description']#中文
e1=data['list'][t]['main']['pressure']
f1=data['list'][t]['main']['temp_max']
g1=data['list'][t]['main']['temp_min']
print('在{},城市:{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b1,a1,c1,d1,e1,f1,g1))
if f1>30:
     print("建议着装:夏装")
if f1<30:
    print("建议着装:春装")   
if d1=='中雨':
    print("出门记得带伞!")
if d1=='多云':
    print("今天多云 适合外出") 
if d1=='小雨':
    print("今天小雨 出门记得带伞!")
print(int(c1)*'-')    
#############  
t=7
a1=data['city']['name']
b1=data['list'][t]['dt_txt']
c1=data['list'][t]['main']['temp']
d1=data['list'][t]['weather'][0]['description']#中文
e1=data['list'][t]['main']['pressure']
f1=data['list'][t]['main']['temp_max']
g1=data['list'][t]['main']['temp_min']
print('在{},城市:{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b1,a1,c1,d1,e1,f1,g1))
if f1>30:
     print("建议着装:夏装")
if f1<30:
    print("建议着装:春装")   
if d1=='中雨':
    print("出门记得带伞!")
if d1=='多云':
    print("今天多云 适合外出") 
if d1=='小雨':
    print("今天小雨 出门记得带伞!")
print(int(c1)*'-')   
t=15
a1=data['city']['name']
b1=data['list'][t]['dt_txt']
c1=data['list'][t]['main']['temp']
d1=data['list'][t]['weather'][0]['description']#中文
e1=data['list'][t]['main']['pressure']
f1=data['list'][t]['main']['temp_max']
g1=data['list'][t]['main']['temp_min']
print('在{},城市:{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b1,a1,c1,d1,e1,f1,g1))
if f1>30:
     print("建议着装:夏装")
if f1<30:
    print("建议着装:春装")   
if d1=='中雨':
    print("出门记得带伞!")
if d1=='多云':
    print("今天多云 适合外出") 
if d1=='小雨':
    print("今天小雨 出门记得带伞!")
print(int(c1)*'-')
t=23
a1=data['city']['name']
b1=data['list'][t]['dt_txt']
c1=data['list'][t]['main']['temp']
d1=data['list'][t]['weather'][0]['description']#中文
e1=data['list'][t]['main']['pressure']
f1=data['list'][t]['main']['temp_max']
g1=data['list'][t]['main']['temp_min']
print('在{},城市:{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b1,a1,c1,d1,e1,f1,g1))
if f1>30:
     print("建议着装:夏装")
if f1<30:1
    print("建议着装:春装")   
if d1=='中雨':
    print("出门记得带伞!")
if d1=='多云':
    print("今天多云 适合外出") 
if d1=='小雨':
    print("今天小雨 出门记得带伞!")
print(int(c1)*'-')
t=31
a1=data['city']['name']
b1=data['list'][t]['dt_txt']
c1=data['list'][t]['main']['temp']
d1=data['list'][t]['weather'][0]['description']#中文
e1=data['list'][t]['main']['pressure']
f1=data['list'][t]['main']['temp_max']
g1=data['list'][t]['main']['temp_min']
print('在{},城市:{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b1,a1,c1,d1,e1,f1,g1))
if f1>30:
     print("建议着装:夏装")
if f1<30:
    print("建议着装:春装")   
if d1=='中雨':
    print("出门记得带伞!")
if d1=='多云':
    print("今天多云 适合外出") 
if d1=='小雨':
    print("今天小雨 出门记得带伞!")
print(int(c1)*'-')
#5.打印出其他10个城市的天气，计算出天气排名，按着大到小的顺序。
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=chongqing,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data=json.loads(data)
c11=data['list'][t]['main']['temp']
a11=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur2='http://api.openweathermap.org/data/2.5/forecast?q=beijing,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur2).read().decode('utf-8')
import json
data=json.loads(data)
c12=data['list'][t]['main']['temp']
a12=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur3='http://api.openweathermap.org/data/2.5/forecast?q=guilin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur3).read().decode('utf-8')
import json
data=json.loads(data)
c13=data['list'][t]['main']['temp']
a13=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur4='http://api.openweathermap.org/data/2.5/forecast?q=xian,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur4).read().decode('utf-8')
import json
data=json.loads(data)
c14=data['list'][t]['main']['temp']
a14=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur5='http://api.openweathermap.org/data/2.5/forecast?q=nanchang,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur5).read().decode('utf-8')
import json
data=json.loads(data)
c15=data['list'][t]['main']['temp']
a15=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur6='http://api.openweathermap.org/data/2.5/forecast?q=laibin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur6).read().decode('utf-8')
import json
data=json.loads(data)
c16=data['list'][t]['main']['temp']
a16=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur7='http://api.openweathermap.org/data/2.5/forecast?q=liuzhou,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur7).read().decode('utf-8')
import json
data=json.loads(data)
c17=data['list'][t]['main']['temp']
a17=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur8='http://api.openweathermap.org/data/2.5/forecast?q=shanghai,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur8).read().decode('utf-8')
import json
data=json.loads(data)
c18=data['list'][t]['main']['temp']
a18=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur9='http://api.openweathermap.org/data/2.5/forecast?q=hangzhou,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur9).read().decode('utf-8')
import json
data=json.loads(data)
c19=data['list'][t]['main']['temp']
a19=data['city']['name']
import urllib.request as r#导入联网工具包，命令为r
ur10='http://api.openweathermap.org/data/2.5/forecast?q=qingdao,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(ur10).read().decode('utf-8')
import json
data=json.loads(data)
c20=data['list'][t]['main']['temp']

print("重庆:"+int(c11)*'*')
print("北京:"+int(c12)*'-')
print("桂林:"+int(c13)*'-')
print("西安:"+int(c14)*'-')
print("南昌:"+int(c15)*'-')
print("来宾:"+int(c16)*'-')
print("柳州:"+int(c17)*'+')
print("上海:"+int(c18)*'-')
print("杭州:"+int(c19)*'-')
print("青岛:"+int(c20)*'-')
ls=[]
ls.append(c11)
ls.append(c12)
ls.append(c13)
ls.append(c14)
ls.append(c15)
ls.append(c16)
ls.append(c17)
ls.append(c18)
ls.append(c19)
ls.append(c20)
lss=sorted(ls)
lss1=reversed(lss)    
print(lss1)
for i in lss1:
    print(i)
   

###############
def msg(b):
    a3=data['city']['name']
    b3=data['list'][b]['dt_txt']
    c3=data['list'][b]['main']['temp']
    d3=data['list'][b]['weather'][0]['description']#中文
    e3=data['list'][b]['main']['pressure']
    f3=data['list'][b]['main']['temp_max']
    g3=data['list'][b]['main']['temp_min']
    print('在{},城市:(来宾){},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b3,a3,c3,d3,e3,f3,g3))
 msg(0)
 msg(2)
 msg(4)
 print("温馨提醒:今天雨转多云，提示带伞,今天温度怡人，穿短袖")
 msg(8)
 msg(10)
 msg(12)
 print("温馨提醒:今天雨转多云，提示带伞,今天温度怡人")
 msg(16)
 msg(18)
 msg(20)
 msg(24)
 msg(26)
 msg(28)
 msg(32)
 msg(34)
 msg(36)
def msg(b):
    a3=data['city']['name']
    b3=data['list'][b]['dt_txt']
    c3=data['list'][b]['main']['temp']
    d33=data['list'][b]['weather'][0]['main']#英文
    e3=data['list'][b]['main']['pressure']
    f3=data['list'][b]['main']['temp_max']
    g3=data['list'][b]['main']['temp_min']
    print('{},city:{},temp:{},description is:{},pressure is:{},temp_max is:{},temp_min is:{}'.format(b3,a3,c3,d33,e3,f3,g3))
 msg(0)
 msg(1)
 msg(5)
 msg(9)
 msg(11)
 msg(13)
 msg(17)
 msg(19)
 msg(21)
 msg(25)
 msg(27)
 msg(29)
 msg(33)

#########################################################
 msg(0)
 msg(2)
 msg(4)
 msg(8)
 msg(10)
 msg(12)
 msg(16)
 msg(18)
 msg(20)
 msg(24)
 msg(26)
 msg(28)
 msg(32)
 msg(34)
 msg(36)






























