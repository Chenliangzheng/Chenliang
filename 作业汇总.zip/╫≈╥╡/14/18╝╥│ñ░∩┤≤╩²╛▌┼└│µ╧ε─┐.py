# -*- coding: utf-8 -*-
"""
Created on Wed Jun 27 09:10:48 2018

======
题目十四：家长帮大数据爬虫项目
1.根据all_school.txt获取全中国学校网址编号：1304，生成一个2300列表
2.根据http://www.gaokaopai.com/daxue-zhaosheng-学校编号.html 获取全国城市的编号 例如北京：11
3.班级团队(需要下载142600(2300*31*2)次)：
    中国划分区域-分组(城市)
    区域分组员
    如何下载策略-分时间下载
    执行人物2300-分配到自己的任务一般是2300
    保存数据---组长全部合并--班长统计
4.待定

@author: Administrator
"""
import urllib.request as r
url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
data='id=2948&type=2&city=50&state=1'.encode()
req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
d=r.urlopen(req).read().decode('utf-8','ignore')
########################################################################## 14(1)
import urllib.request as r
url='file:///C:/Users/Administrator/all_school.txt'
data=r.urlopen(url).read().decode('utf-8')
import re
ls=re.compile('com/daxue-jianjie-(.*?).html').findall(data)#大学编码
ls0=re.compile('(.*?)\t.*\t').findall(data)#大学
print(ls)
print(ls0)#学校网址编号
#http://www.gaokaopai.com/daxue-jianjie-477.html
#http://www.gaokaopai.com/daxue-zhaosheng-477.html
import urllib.request as r#导入URL工具包 并且命令为r
req=r.Request('http://www.gaokaopai.com/daxue-zhaosheng-477.html',headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36'})
myurl=r.urlopen(req)
print(myurl.getcode())
print('城市-编号')
data=myurl.read().decode('utf-8')
pat1="\S.setVar\S'claimCity', (.*?)\S\S>"
pat2="data-id=\S2\S onclick=\S\S.setVar\S'claimCity', \d\d\S\S>(.*?)</li>"
import re
ls1=re.compile(pat1,re.S).findall(data)#城市编码
ls2=re.compile(pat2,re.S).findall(data)#省份
for i in range(len(ls1)):
    print('{}-{}\n'.format(ls2[i],ls1[i]))
#######################################################################团队项目  
import urllib.request as r
url='file:///C:/Users/Administrator/all_school.txt'
data=r.urlopen(url).read().decode('utf-8')
import re
ls=re.compile('com/daxue-jianjie-(.*?).html').findall(data)#大学编码
ls0=re.compile('(.*?)\t.*\t').findall(data)#大学
import urllib.request as r
import urllib.request as r
for i in ls:
    url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
    data='id={}&type=1&city=64&state=1'.format(i).encode()    
    req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
    dd=r.urlopen(req).read().decode('utf-8','ignore')
    if dd[0]=='{':
        f=open('./a.txt','a')
        f.write(dd+'\n')
        f.close()
    else:
        while dd[0]!='{':
                url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
                data='id={}&type=1&city=64&state=1'.format(i).encode()    
                req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
                dd=r.urlopen(req).read().decode('utf-8','ignore')         
        f=open('./a.txt','a')
        f.write(dd+'\n')
        f.close()
################################################
f=open('./宁夏文.txt')
ls=f.readlines()#每一条网址
for line in ls:
    print(line)
ls2=[]
import json
for i in ls:
    i=json.loads(i)
    ls2.append(i)#生成各个大学在某个城市的例表
for i in range(2300):
    if ls2[i]['status']==1:
        ls3=ls2[i]['data']
    for j in range(len(ls2[i]['data'])):
        school=ls3[j]['school']
        profess=ls3[j]['profess']
        renshu=ls3[j]['plan']
        renshu=int(renshu)
        print("{}的{}专业在宁夏招文科生{}人：".format(school,profess,renshu))
##########################################   
f=open('./宁夏文.txt','r',encoding='utf-8')  
data=f.read()
import re
lss=re.compile('"plan":"(.*?)"').findall(data)
a=0
for i in range(len(lss)):
    a=a+int(lss[i])
print('宁夏文科人数是:{}'.format(a))
f=open('./宁夏理.txt','r',encoding='utf-8')  
data=f.read()
import re
lss=re.compile('"plan":"(.*?)"').findall(data)
a=0
for i in range(len(lss)):
    a=a+int(lss[i])
print('宁夏理科人数是:{}'.format(a))
f=open('./新疆理.txt','r',encoding='utf-8')  
data=f.read()
import re
lss=re.compile('"plan":"(.*?)"').findall(data)
a=0
for i in range(len(lss)):
    a=a+int(lss[i])
print('新疆理科人数是:{}'.format(a))
f=open('./新疆文.txt','r',encoding='utf-8')  
data=f.read()
import re
lss=re.compile('"plan":"(.*?)"').findall(data)
a=0
for i in range(len(lss)):
    a=a+int(lss[i])
print('新疆文科人数是:{}'.format(a))
f=open('./内蒙古文.txt','r',encoding='utf-8')  
data=f.read()
import re
lss=re.compile('"plan":"(.*?)"').findall(data)
a=0
for i in range(len(lss)):
    a=a+int(lss[i])
print('内蒙古文科人数是:{}'.format(a))
f=open('./内蒙古理.txt','r',encoding='utf-8')  
data=f.read()
import re
lss=re.compile('"plan":"(.*?)"').findall(data)
a=0
for i in range(len(lss)):
    a=a+int(lss[i])
print('内蒙古理科人数是:{}'.format(a))












