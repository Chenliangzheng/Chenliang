# -*- coding: utf-8 -*-
"""
Spyder Editor
ctrl +   方法字体
ctrl enter  选中运行
第一题
1.定义一个天气列表。写出里面一周每个温度
2.打印出7天的天气，并且如果是星期三的话，打印星期三是X度

This is a temporary script file.
"""
############################################################## 作业1
g=['15°','17°','23°','24°','22°','16.7°','23°']
print(g[0])
print(g[1])
print(g[2])
print(g[3])
print(g[4])
print(g[5])
print(g[6])  
a=g[2]
print("星期三是："+a)
print("星期三是："+g[2])
###########
