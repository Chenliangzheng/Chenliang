# -*- coding: utf-8 -*-
"""
Created on Fri Jun 22 09:19:32 2018


练习七:全球天气未来3天
1.使用多选其一，完成天气的提醒
2.一定要多ci使用到for循环,偶尔用一次while循环
3.初步学会使用debug，知道里面的设置断点，下一步执行，下一个断点执行。
4.《闪屏的制作》进入我们天气程序的时候，有一个温馨图形的提示。使用循环实现，
  要知道是什么意思，照抄网上代码不行。
@author: Administrator
"""
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=laibin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data=json.loads(data)
print('天气提醒：')
for i in range(20):
    if i==1:
        print('*'*2,'♡','*'*2)
    elif i==2:
        print('*'*2,'天','*'*2)
    elif i==3:
        print('*'*2,'气','*'*2)
    elif i==4:
        print('*'*2,'预','*'*2)
    elif i==5:
        print('*'*2,'报','*'*2)
    elif i==6:
        print('*'*2,'♡','*'*2)         
    elif i==7:
        print('*'*2,'预','*'*2)    
    elif i==8:
        print('*'*2,'防','*'*2)
    elif i==9:
        print('*'*2,'感','*'*2)    
    elif i==10:
        print('*'*2,'冒','*'*2)
    elif i==11:
        print('*'*2,'♡','*'*2)

for b in range(0,30,1):
    a1=data['city']['name']
    b1=data['list'][b]['dt_txt']
    c1=data['list'][b]['main']['temp']
    d1=data['list'][b]['weather'][0]['description']#中文
    e1=data['list'][b]['main']['pressure']
    f1=data['list'][b]['main']['temp_max']
    g1=data['list'][b]['main']['temp_min']
###)(1)     
    if d1=='多云':
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★此时多云 适宜外出')
    elif d1=='阴，多云':
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★此时阴转多云 不建议外出')
    while d1=='小雨':
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★小雨 外出记得带伞')
        break
####(2)
    if d1=='多云':
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★此时多云 适宜外出')
    elif d1=='阴，多云':
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★此时阴转多云 不建议外出')
    elif d1=='小雨':
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★小雨 外出记得带伞')
    else:
        print('city:laibin,在{},温度是:{},情况是:{}'.format(b1,c1,d1),'★')



s='太阳不再上升'
if '太阳不再上升'==s:
    print('xxxx')
#
ls=['当太阳不再上升的时候','当地球不再转动','当春夏秋冬不再变换','当花草树木全部凋残']
print('wo' in ls)
print('当地球不再转动' in ls)
#这种循环和列表很搭  
for line in ls:
    print(line)
    
ls=range(9)
for i in ls:
    print(i)

for i in range(0,9,1):
    print(i)

for i in range(0,9,2):
    print(i)

#固定次数的循环和列表和搭配
#还有一种循环，是没有次数限制的。有死循环，
for i in range(0,999999):
    print(i)

while True:#当什么时候
    print('kdlfjdkfjlkd')

############################
for i in range(1,101):
    print('跑第{}圈'.format(i))
    if i==3:
        break
    
for i in range(1,20):
    if i==10:
        print('幸运通道，执行进入下一次')
        continue
    print('跑第{}圈'.format(i))

###########
for i in [1,2,3]:
    print(i)
    for j in [0.1,0.2,0.3]:
        print(j)
























