# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 08:57:33 2018

题目九：余票查询组项目
1.查询某种火车的余票，动车，高铁，直达，特快....
2.组长将各组员功能汇总
@author: Administrator
"""
import urllib.request as r#导入联网工具包，命令为r
url='https://kyfw.12306.cn/otn/leftTicket/query?leftTicketDTO.train_date=2018-06-26&leftTicketDTO.from_station=SHH&leftTicketDTO.to_station=NJH&purpose_codes=ADULT '
data1=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data1=json.loads(data1)
data1=data1['data']['result']
p='  '
title='车次{}出发站/到达站{}出发时间/到达时间{}历时{}商务座/特等座{}一等座{}二等座{}高级软卧{}软卧{}动卧{}硬卧{}软座{}硬座{}无座{}其他{}备注'.format(p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p)
title=title.split(p)
for i in title:
    print(i.center(12),end='')
print()
for i in range(274):
    a1=data1[i]
    ls=a1.split('|')
    if ls[3][:1]!='T' and ls[3][:1]!='Z' and ls[3][:1]!='G' and ls[3][:1]!='K' and ls[3][:1]!='D':
        ls=[ls[3],[ls[6],ls[7]],[ls[8],ls[9]],ls[10],'--','--','--','--',ls[23],'--',ls[26],'--',ls[28],ls[29],'--',ls[1]]
        for j in ls:
            print(str(j).center(15).replace('[','').replace(']','').replace('SHH','上海').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NJH','南京').replace('NKH','南京南'),end='')
        print('\n')
for i in range(274):
    a1=data1[i]
    ls=a1.split('|')
    if ls[3][:1]=='T':  
        ls=[ls[3],[ls[6],ls[7]],[ls[8],ls[9]],ls[10],'--','--','--',ls[21],ls[23],'--',ls[28],'--',ls[29],ls[26],'--',ls[1]]
        for i in ls:
            print(str(i).center(15).replace('[','').replace(']','').replace('SHH','上海').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NJH','南京').replace('NKH','南京南'),end='')
        print('\n')
for i in range(274):
    a1=data1[i]
    ls=a1.split('|')    
    if ls[3][:1]=='D':
        ls=[ls[3],[ls[6],ls[7]],[ls[8],ls[9]],ls[10],ls[32],ls[31],ls[30],'--','--','--','--','--','--',ls[26],'--',ls[1]]
        for k in ls:
            print(str(k).center(15).replace('[','').replace(']','').replace('SHH','上海').replace('NJH','南京').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NKH','南京南'),end='')
        print('\n')
for i in range(274):
    a1=data1[i]
    ls=a1.split('|')
    if ls[3][:1]=='K':
        ls=[ls[3],[ls[6],ls[7]],[ls[8],ls[9]],ls[10],'--','--','--','--',ls[23],'--',ls[28],'--',ls[29],ls[26],'--']
        for i in ls:
            print(str(i).center(15).replace('[','').replace(']','').replace('SHH','上海').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NJH','南京').replace('NKH','南京南'),end='') 
        print('\n')
for i in range(274):
    a1=data1[i]
    ls=a1.split('|')
    if ls[3][:1]=='Z':
        ls=[ls[3],[ls[5],ls[7]],[ls[8],ls[9]],ls[10],ls[32],ls[31],ls[30],'--',ls[23],'--',ls[26],ls[27],ls[28],ls[29],'--',ls[1]]
        for i in ls:
            print(str(i).center(13).replace('[','').replace(']','').replace('SHH','上海').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NJH','南京').replace('NKH','南京南'),end=' ')
        print('\n')
for i in range(274):
    a1=data1[i]
    ls=a1.split('|')
    if ls[3][:1]=='G':
        if ls[32]=='无' and ls[31]=='无' and ls[30]=='无':
            lsd=[ls[3],[ls[6],ls[7]],[ls[8],ls[9]],ls[10],ls[32],ls[31],ls[30],'--','--','--','--','--','--',ls[26],'--','XXXXXX']
            for b in lsd[:3]:
                print(str(b).center(16).replace('[','').replace(']','').replace('SHH','上海').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NJH','南京').replace('NKH','南京南'),end='')
            for b in lsd[3:8]:
                print(str(b).center(15).replace('[','').replace(']',''),end='')
            for b in lsd[8:]:
                print(str(b).center(14).replace('[','').replace(']',''),end='')
        else:
            lsd=[ls[3],[ls[6],ls[7]],[ls[8],ls[9]],ls[10],ls[32],ls[31],ls[30],'--','--','--','--','--','--',ls[26],'--',ls[1]]
            for b in lsd[:3]:
                print(str(b).center(16).replace('[','').replace(']','').replace('SHH','上海').replace('SNH','上海南').replace('AOH','上海虹桥').replace('NJH','南京').replace('NKH','南京南'),end='')
            for b in lsd[3:8]:
                print(str(b).center(15).replace('[','').replace(']',''),end='')
            for b in lsd[8:]:
                print(str(b).center(14).replace('[','').replace(']',''),end='')
            print('\n')
#print('车次')
#print('ab')









