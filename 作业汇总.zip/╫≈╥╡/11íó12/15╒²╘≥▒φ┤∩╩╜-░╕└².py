 #-*- coding: utf-8 -*-
"""
Created on Tue Jun 26 09:48:02 2018
爬取百度网页数据，用http:// 而不是其他
题目十一：爬取百度网页数据
1.爬取百度搜索标题
2.爬取标题下的描述
3.搜索的标题的网站
题目十二：使用re爬取天气信息
1.天气描述，天气温度，天气气压

@author: Administrator
"""
######################################## 作业11
import urllib.request as r#导入联网工具包，命令为r
url='http://www.baidu.com/s?wd=%E6%A1%82%E6%9E%97%E6%97%85%E6%B8%B8&rsv_spt=1&rsv_iqid=0xfeeeefb400000aa5&issp=1&f=8&rsv_bp=0&rsv_idx=2&ie=utf-8&tn=baiduhome_pg&rsv_enter=0&rsv_sug3=9&rsv_sug1=5&rsv_sug7=100&rsv_t=84ceQlajV%2FgKD2E8wqEoRFIQyEBj6By395OObooR0tYBnmE287PyZKzwte12vMQdHtCX&inputT=10795&rsv_sug4=11498'
data=r.urlopen(url).read().decode('utf-8')
print(data)
import re
ls1=re.compile('title":"(.*?)"url":"http://').findall(data)
ls2=re.compile('class="c-abstract">(.*?)</div>').findall(data)
ls3=re.compile('none;">(.*?)&nbsp;').findall(data)
for i in range(len(ls1)):
    print('标题:{}\n相关描述:{}\n网址:{}\n'.format(ls1[i],ls2[i],ls3[i]).replace('</em>','').replace('<','').replace('e','').replace('m','').replace('>',''))
######################################## 作业12
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=liuzhou,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
temp_data=r.urlopen(url).read().decode('utf-8')
print(temp_data)
import re
ls1=re.compile('"dt_txt":"(.*?)"').findall(temp_data)
ls2=re.compile('"description":"(.*?)"').findall(temp_data)
ls3=re.compile('"temp":(.*?),').findall(temp_data)
ls4=re.compile('"pressure":(.*?)"').findall(temp_data)
for i in range(len(ls1)):
    print('日期:{}描述:{}温度:{}气压:{}\n'.format(ls1[i],ls2[i],ls3[i],ls4[i]))
    
    

    
    