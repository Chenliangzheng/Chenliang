# -*- coding: utf-8 -*-
"""
Created on Tue Jun 26 14:26:02 2018
URL(Uniform Resource Locator,统一资源定位符)本地、网络 路径
############题目
题目十三：糗事百科数据爬取
1.爬取作者和内容
2.爬取13页
3.下载图片。想做就做


@author: Administrator
"""

################################################### 13题
import urllib.request as r#导入URL工具包 并且命令为r
for j in range(1,14):
    req=r.Request('http://www.qiushibaike.com/8hr/page/{}/'.format(j),headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36'})
    myurl=r.urlopen(req)
    print(myurl.getcode())
    print('第{}页'.format(j))
    data=myurl.read().decode('utf-8')
    pat1='<h2>(.*?)</h2>'
    pat2='div class="content">(.*?)</span>'
    import re
    ls1=re.compile(pat1,re.S).findall(data)
    ls2=re.compile(pat2,re.S).findall(data)
    for i in range(len(ls1)):
        print('作者:{}\n发布内容:{}\n'.format(ls1[i],ls2[i]).replace('<span>',''))




















