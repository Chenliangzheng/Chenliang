# -*- coding: utf-8 -*-
"""
Created on Wed Jun 20 16:13:19 2018
第三题：
1.通过复制联网代码获得天气(老家)字典数据
2.打印温度temp,天气情况description,天气气压pre
@author: Administrator
"""

###########################################################作业3
import urllib.request as r#导入联网工具包，命令为r
ur2='http://api.openweathermap.org/data/2.5/weather?q=laibin&mode=json&units=metric&lang=zh_cn&APPID=6a67ed641c0fda8b69715c43518b6996'
data=r.urlopen(ur2).read().decode('utf-8')
import json
data=json.loads(data)
a=data['main']['temp']
print("来宾的温度是:",data['main']['temp'])
print("来宾的气压是：",data['main']['pressure'])
print("来宾的天气情况是："+data['weather'][0]['description'])