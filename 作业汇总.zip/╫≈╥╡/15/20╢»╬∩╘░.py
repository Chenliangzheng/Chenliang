# -*- coding: utf-8 -*-
"""
Created on Fri Jun 29 08:53:44 2018

题目十五：未来三天 天气类天气对象
1.定义一个天气类Weather 静态的属性(temp,description,pre) 动态属性(msg打印当前天气属性)
2.创建3天的天气对象，并调用msg方法
题目十六：高考派2300数据统计
1.根据2300下载的两百多M文件，统计招生总人数
2.统计7各地域的人数各是多少
3.计算比例
@author: Administrator
"""

###############################################################################15
tianqi={"temp":['20','19','25'],"description":['晴','多云','小雨'],"presure":['100','200','125']}
class Tianqi:
    def __init__(self,tim,tem,des,pre):
        self.tim=tim
        self.tem=tem
        self.des=des
        self.pre=pre
    def msg(self):
        print('时间{}，温度{}，情况{}，压强{}'.format(self.tim,self.tem,self.des,self.pre))
a=Tianqi('12:00','39°','晴','600')
b=Tianqi('12:00','30°','小雨','900')
c=Tianqi('12:00','35°','多云','800')
a.msg()
b.msg()
c.msg()
###############################################################################15
import urllib.request as r#导入联网工具包，命令为r
url='http://api.openweathermap.org/data/2.5/forecast?q=laibin,cn&mode=json&lang=zh_cn&&APPID=6a67ed641c0fda8b69715c43518b6996&units=metric'
data=r.urlopen(url).read().decode('utf-8')
import json
data=json.loads(data)
def msg(b):
    a1=data['city']['name']
    b1=data['list'][b]['dt_txt']
    c1=data['list'][b]['main']['temp']
    d1=data['list'][b]['weather'][0]['description']#中文
    e1=data['list'][b]['main']['pressure']
    f1=data['list'][b]['main']['temp_max']
    g1=data['list'][b]['main']['temp_min']
    print('在{},城市:{},温度是:{},情况是:{},气压是:{},最高温度是:{},最低温度是:{}'.format(b1,a1,c1,d1,e1,f1,g1))
 msg(0)
 msg(2)
 msg(4)

























