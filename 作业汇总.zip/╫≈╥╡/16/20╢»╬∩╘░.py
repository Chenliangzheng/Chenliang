# -*- coding: utf-8 -*-
"""
Created on Fri Jun 29 08:53:44 2018
题目十六：高考派2300数据统计
1.根据2300下载的两百多M文件，统计招生总人数
2.统计7各地域的人数各是多少
3.计算比例
@author: Administrator
"""
###################################################################################宁夏文
import urllib.request as r
url='file:///C:/Users/Administrator/all_school.txt'
data=r.urlopen(url).read().decode('utf-8')
import re
ls=re.compile('com/daxue-jianjie-(.*?).html').findall(data)#大学编码
ls0=re.compile('(.*?)\t.*\t').findall(data)#大学
print(ls)
print(ls0)#学校网址编号
import urllib.request as r
for i in ls:
    url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
    data='id={}&type=1&city=15&state=1'.format(i).encode()    
    req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
    dd=r.urlopen(req).read().decode('utf-8','ignore')
    if dd[0]=='{':
        f=open('./c.txt','a')
        f.write(dd+'\n')
        f.close()
    else:
        while dd[0]!='{':
                url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
                data='id={}&type=1&city=15&state=1'.format(i).encode()    
                req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
                dd=r.urlopen(req).read().decode('utf-8','ignore')         
        f=open('./c.txt','a')
        f.write(dd+'\n')
        f.close()
####################################################################################新疆文        
f=open('all_school.txt','r',encoding='utf-8')
a=f.read()
import re
ls=re.compile('jianjie-(.*?).html').findall(a)
lsx=re.compile('(.*?)\t.*\t').findall(a)

for x in range(2300):
    url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
    data='id={}&type=1&city=65&state=1'.format(ls[x]).encode()
    req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
    d=r.urlopen(req).read().decode('utf-8','ignore')
    if d[0]=='{':
        f=open('./1.txt','a')
        f.write(d+"\n")
        f.close()
        print(x)
    else:
        while d[0]!='{':
            url='http://www.gaokaopai.com/university-ajaxGetMajor.html'
            data='id={}&type=1&city=65&state=1'.format(ls[x]).encode()
            req=r.Request(url,data=data,headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36','X-Requested-With':'XMLHttpRequest'})
            d=r.urlopen(req).read().decode('utf-8','ignore')
        f=open('./1.txt','a')
        f.write(d+"\n")
        f.close()
        
























