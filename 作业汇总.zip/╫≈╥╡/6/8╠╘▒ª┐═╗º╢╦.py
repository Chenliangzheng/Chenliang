# -*- coding: utf-8 -*-
"""
Created on Thu Jun 21 15:52:44 2018
练习六：获取淘宝数据并且展示(只要第一页的商品48个)
1.每一行显示4个商品信息(商品名，价格，付款，店铺名,地址，)
2.列出12排商品
3.给商品排序，从价格高到低
4.给商品排序，按照销量排序
5.商品过滤，只要15天退款的商品，包邮的商品

@author: Administrator
"""
###########################################################作业6
import urllib.request as r#导入联网工具包，命令为r
url='https://s.taobao.com/search?q=%E7%BE%BD%E7%BB%92%E6%9C%8D&bcoffset=3&ntoffset=3&p4ppushleft=1%2C48&s=44&ajax=true'
data=r.urlopen(url).read().decode('utf-8')
#讲str类型转换为dict
import json
data=json.loads(data)
for i in range(0,43):
    for j in range(4):
        a=data['mods']['itemlist']['data']['auctions'][i+j*4]['raw_title']#商品名
        b=data['mods']['itemlist']['data']['auctions'][i+j*4]['view_price']#价格
        c=data['mods']['itemlist']['data']['auctions'][i+j*4]['view_sales']#付款
        d=data['mods']['itemlist']['data']['auctions'][i+j*4]['nick']#店铺名
        e=data['mods']['itemlist']['data']['auctions'][i+j*4]['item_loc']#地址
        print('商品名:{},价格:{},付款:{},店铺名:{},地址:{}'.format(a,b,c,d,e))        
    print('\t★★★')
#############################################6(3)
for i in range(0,43):
    a=data['mods']['itemlist']['data']['auctions'][i]['raw_title']#商品名
    b=data['mods']['itemlist']['data']['auctions'][i]['view_price']#价格
    print('商品名:{},价格:{}'.format(a,b))
print('按照价格由高到低：')
ls=[]
for i in range(0,43):
    b=data['mods']['itemlist']['data']['auctions'][i]['view_price']#价格
    bb=float(b)
    ls.append(bb)   
ls=sorted(ls)
#print(ls) 由低到高
lss=sorted(ls,reverse=True)
print(lss)
#############################################6(4)
print('按照销量由高到低：')
ls=[]
for i in range(0,43):
    c=data['mods']['itemlist']['data']['auctions'][i]['view_sales']#付款
    cc=float(c[:-3])
    ls.append(cc)   
lsc=sorted(ls)
#print(lsc) #由低到高
lssc=sorted(lsc,reverse=True)
print(lssc)
#############################################6(5)
for i in range(0,43):
    a=data['mods']['itemlist']['data']['auctions'][i]['raw_title']#商品名
    f=data['mods']['itemlist']['data']['auctions'][i]['view_fee']
    print('商品名:{}，邮费:{}'.format(a,f))
    if f=='0.00':
        print('\t包邮')
    else:
        print('\t★此商品不包邮')










































    print('商品名:',a+' 价格:',b+' 付款:',c+' 店铺名:',d+' 地址:',e)
    print('商品名:',a)
    print('价格:',b)
    print('付款:',c)
    print('店铺名:',d)
    print('地址:',e)
for i in range(1,20):
    if i==10:
        print('幸运通道hhah')
        continue
    print('跑了{}圈'.format(i))







