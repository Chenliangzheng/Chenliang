# -*- coding: utf-8 -*-
"""
Created on Tue Jul  3 15:02:56 2018

@author: Administrator
"""
import turtle
import urllib.request as r#导入联网工具包，命令为r
import re

#画矩形立方体
def draw_cube(i):   
    turtle.begin_fill()  
    turtle.color("black")
    turtle.speed('fast')    
    turtle.goto(i,i*3)
    turtle.goto(100+i,i*3)
    turtle.goto(100+i,20+i*3)
    turtle.goto(i,20+i*3)
    turtle.goto(i,i*3)
    turtle.end_fill()
    turtle.penup()
    turtle.goto(i,20+i*3)
    turtle.pendown()
    turtle.goto(10+i,30+i*3)
    turtle.goto(110+i,30+i*3)
    turtle.goto(110+i,10+i*3)
    turtle.goto(100+i,i*3)
    turtle.penup()
    turtle.goto(100+i,20+i*3)
    turtle.pendown()
    turtle.goto(110+i,30+i*3)
#画笑脸
def draw_smile_face(x,y):
    turtle.goto(x+50,y)
    turtle.pensize(1.5)
 #脸部
    turtle.circle(20)
    turtle.penup()
#眼睛
    turtle.goto(x+40,y+20)
    turtle.pendown()
    turtle.begin_fill()  
    turtle.color("red")
    turtle.circle(3)
    turtle.end_fill()
    turtle.penup()
    turtle.goto(x+60,y+20)
    turtle.pendown()
    turtle.begin_fill()  
    turtle.color("red")
    turtle.circle(3)
    turtle.end_fill()
    turtle.penup()
    turtle.color("black")
 #嘴巴
    turtle.goto(x+45,y+10)
    turtle.pendown()
    turtle.right(90)
    turtle.pensize(2)
    turtle.circle(5,180)   
def main():
    turtle.speed(2)
    for i in range(0,100,10):
        draw_cube(i)
    draw_smile_face(100,300)
    turtle.hideturtle()
    turtle.exitonclick()
main()

print('----------------------------------------------------------------------')
print('                   Welcome to  皮 小 亮 小 说 库  ▼   ▼                ')
print('---------------------------------------------------皿-----------------')
 
print('                                9                                     ')
print('                        6666666666666669                              ')
print('                        6       6     6                               ')
print('                        6       6                                     ')
print('                        6   666666666                                 ')
print('                        9   6       9                                 ')
print('                        6     6    6                                  ')
print('                       6       696                                    ')
print('                     6       6    6                                   ')
print('                    6      6         669                              ')
print('                                                       ~       ~      ') 
print('                                      皮一下就特别开心  · ω ·          ')
print('                                                                      ') 
print('======================================================================')
    


def msg1(b):
    ls2=[]
    c=r.quote(b)
    url1='https://www.23us.cc/SearchBook.php?t=920895234054625192&keyword={}'.format(c)
    data2=r.urlopen(url1).read().decode('UTF-8')
    ls2.append(re.compile('target="_blank">(.*?)</a><i>.*?class="s3">{}</span>'.format(b)).findall(data2))
    return ls2

it=input('(在线阅读：1/下载：2)==')
if it=='1':
    KS=''
    while KS=='':
        zzm=input('请输入作者名/小说名：')
        if msg1(zzm)!=[[]]:
            print('该作者有小说：{}'.format(msg1(zzm))) 
            novel=input('请输入小说名:')
        else:
            novel=zzm
        a=r.quote(novel)
        url1='https://www.23us.cc/SearchBook.php?t=920895234054625192&keyword={}'.format(a)
        data1=r.urlopen(url1).read().decode('UTF-8')
        ls1=re.compile('<span class="s2"><a href="(.*?)" target="_blank">{}</a><i>'.format(novel)).findall(data1)
        if ls1==[]:
            print('(名字都记不住，看你麻痹!!!)')
            print('++++++++没有找到这本小说哦，你要找的是不是这些哦++++++++')
            ls2=re.compile('target="_blank">(.*?)</a><i><a href').findall(data1)
            for i in ls2:
                print(i,end='\n')
            continue
        url2='https://www.23us.cc{}'.format(ls1[0])
        data2=r.urlopen(url2).read().decode('UTF-8')
        ls2=re.compile('<dd> <a style=""=style="" href="(.*?).html">(.*?)</a></dd>').findall(data2)
        for i in range(len(ls2)):
            print('{}-{}'.format(i,ls2[i][1]))
        JS=''
        while JS=='':
            chapter=input('请输入章节的数字(回车返回)：')
            if chapter=='':
                break
            chapter=int(chapter)
            url3='https://www.23us.cc{}{}.html'.format(ls1[0],ls2[chapter][0])
            data3=r.urlopen(url3).read().decode('UTF-8')
            ls3=re.compile('<div id="content">(.*?)</div>',re.S).findall(data3)
            ls3=ls3[0].replace('<br/>','\n')
            ls4=ls3.replace('&nbsp;','')
            print(ls2[int(chapter)][1].center(188),end=' ')
            print(ls4)
            JS=input('回车键选择章节(任意键+回车键退出)：')
        KS=input('回车键选择小说(任意键+回车键退出)：')
else:
    novel=input('请输入小说名:')
    number=input('请输入开始章节-结束章节：')
    a=r.quote(novel)
    b1=int(number.split('-')[0])
    b2=int(number.split('-')[1])
    url1='https://www.23us.cc/SearchBook.php?t=920895234054625192&keyword={}'.format(a)
    data1=r.urlopen(url1).read().decode('UTF-8')
    ls1=re.compile('<span class="s2"><a href="(.*?)" target="_blank">{}</a><i>'.format(novel)).findall(data1)
    url2='https://www.23us.cc{}'.format(ls1[0])
    data2=r.urlopen(url2).read().decode('UTF-8')
    ls2=re.compile('<dd> <a style=""=style="" href="(.*?).html">(.*?)</a></dd>').findall(data2)
    f=open('./{}.txt'.format(novel),'w',errors='backslashreplace')
    for i in range(b1,b2):
        url3='https://www.23us.cc{}{}.html'.format(ls1[0],ls2[i][0])
        data3=r.urlopen(url3).read().decode('UTF-8')
        ls3=re.compile('<div id="content">(.*?)</div>',re.S).findall(data3)
        ls3=ls3[0].replace('<br/>','\n')
        ls4=ls3.replace('&nbsp;','').replace('\ue004','')
        f.write(ls4)
    f.close()
        
    
        
        
      

        
        
        
        
        
        
        
        
        
        
        
        

        






            
        



        
    
    











